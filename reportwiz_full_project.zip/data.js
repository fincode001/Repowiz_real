// data.js - 샘플 목적용 더미 데이터
// 실제 프로젝트에서는 선택 옵션에 따라 동적으로 사용됨
const dataMap = {
    "보고서": {
        "기획 보고서": { tone: "논리적", format: "Word" },
        "시장 조사 보고서": { tone: "분석적", format: "PDF" }
    },
    "회의자료": {
        "주간 회의안": { tone: "간결한", format: "PPT" },
        "월간 브리핑": { tone: "설득력 있는", format: "PPT" }
    },
    "요약자료": {
        "논문 요약": { tone: "전문적", format: "Markdown" },
        "기사 요약": { tone: "가벼운", format: "HTML" }
    }
};